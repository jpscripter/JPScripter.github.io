$impersonationsig = @'
using System;
using System.Runtime.InteropServices;

public enum SECURITY_IMPERSONATION_LEVEL {
    SecurityAnonymous,
    SecurityIdentification,
    SecurityImpersonation,
    SecurityDelegation
}

[StructLayout(LayoutKind.Sequential)]
public struct SECURITY_ATTRIBUTES
{
    public int nLength;
    public unsafe byte* lpSecurityDescriptor;
    public int bInheritHandle;
}


[StructLayout(LayoutKind.Sequential, CharSet=CharSet.Auto)]
public struct StartupInfo
{
    public int    cb;
    public String reserved;
    public String desktop;
    public String title;
    public int    x;
    public int    y;
    public int    xSize;
    public int    ySize;
    public int    xCountChars;
    public int    yCountChars;
    public int    fillAttribute;
    public int    flags;
    public UInt16 showWindow;
    public UInt16 reserved2;
    public byte   reserved3;
    public IntPtr stdInput;
    public IntPtr stdOutput;
    public IntPtr stdError;
} 

public struct ProcessInformation
{
    public IntPtr process;
    public IntPtr thread;
    public int    processId;
    public int    threadId;
}


public enum CreationFlags 
{
   CREATE_SUSPENDED       = 0x00000004,
   CREATE_NEW_CONSOLE     = 0x00000010,
   CREATE_NEW_PROCESS_GROUP   = 0x00000200,
   CREATE_UNICODE_ENVIRONMENT = 0x00000400,
   CREATE_SEPARATE_WOW_VDM    = 0x00000800,
   CREATE_DEFAULT_ERROR_MODE  = 0x04000000,
}

public enum LogonFlags 
{
   DEFAULT     = 0x00000000,
   LOGON_WITH_PROFILE     = 0x00000001,
   LOGON_NETCREDENTIALS_ONLY  = 0x00000002    
}

public enum TOKEN_TYPE 
{
    TokenPrimary = 1,
    TokenImpersonation
}

namespace Pinvoke {
    public static class advapi32 {


        [DllImport("advapi32.dll")]
        public extern static bool DuplicateToken(
            IntPtr ExistingTokenHandle, int
            SECURITY_IMPERSONATION_LEVEL,
            ref IntPtr DuplicateTokenHandle
        );

        [DllImport("advapi32.dll", CharSet=CharSet.Auto, SetLastError=true)]
        public extern static bool DuplicateTokenEx(
            IntPtr hExistingToken,
            uint dwDesiredAccess,
            ref SECURITY_ATTRIBUTES lpTokenAttributes,
            SECURITY_IMPERSONATION_LEVEL ImpersonationLevel,
            TOKEN_TYPE TokenType,
            out IntPtr phNewToken 
        );

        [DllImport("advapi32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool OpenProcessToken(
            IntPtr ProcessHandle, 
            UInt32 DesiredAccess, 
            out IntPtr TokenHandle
        );

        [DllImport("advapi32.dll", SetLastError=true, CharSet=CharSet.Unicode)]
        public static extern bool CreateProcessWithLogonW(
           String             userName,
           String             domain,
           String             password,
           LogonFlags         logonFlags,
           String             applicationName,
           String             commandLine,
           CreationFlags          creationFlags,
           UInt32             environment,
           String             currentDirectory,
           ref  StartupInfo       startupInfo,
           out ProcessInformation     processInformation);

           [DllImport("advapi32.dll", SetLastError=true)]
            public static extern bool LogonUserEx(
            string lpszUsername,
            string lpszDomain,
            string lpszPassword,
            int dwLogonType,
            int dwLogonProvider,
            out IntPtr phToken,
            IntPtr ppLogonSid, // nullable
            IntPtr ppProfileBuffer, // nullable
            IntPtr pdwProfileLength, // nullable
            IntPtr pQuotaLimits // nullable
            );

    }
}

'@

<#
  Interactive = 2
  Network = 3
  Batch = 4
  Service = 5
  Unlock = 7
  NetworkClearText = 8
  NewCredentials = 9
  #>
$cp = New-Object System.CodeDom.Compiler.CompilerParameters
$cp.CompilerOptions = '/unsafe'
add-type $impersonationsig -CompilerParameters $cp




# get system
foreach ($process in (Get-process)){
    [intptr] $ProcessToken = 0
    Try {
        $status = [Pinvoke.advapi32]::OpenProcessToken($process.handle, [security.principal.tokenaccesslevels]::Duplicate,[ref]$ProcessToken)
    }
    Catch{
        $status = $false
    }
    If ($status){
        write-verbose -Message $process.name
        $processOwner = ([wmi]"\\.\root\cimv2:Win32_Process.Handle='$($process.id)'").getowner()
        If ($ProcessOwner.user -eq 'SYSTEM') {
            Break
        }
    }

}
Write-output -InputObject $ProcessToken

# duplicate token
[intptr] $ImpersonationToken = 0
$SecurityAttibutes = New-object SECURITY_ATTRIBUTES
$SecurityAttibutes.nLength = [System.Runtime.InteropServices.Marshal]::SizeOf($SecurityAttibutes)
$status = [Pinvoke.advapi32]::DuplicateTokenEx($ProcessToken, [System.Security.Principal.TokenAccessLevels]::MaximumAllowed, [ref] $SecurityAttibutes, [SECURITY_IMPERSONATION_LEVEL]::SecurityImpersonation, [TOKEN_TYPE]::TokenImpersonation, [ref] $ImpersonationToken)

$status 

[System.Security.Principal.WindowsIdentity]::GetCurrent().name
[System.Security.Principal.WindowsIdentity]::Impersonate($ImpersonationToken)
[System.Security.Principal.WindowsIdentity]::GetCurrent().name
start-job -ScriptBlock {[System.Security.Principal.WindowsIdentity]::GetCurrent().name}
get-job job2 |Select-Object output
pause



[System.Security.Principal.WindowsIdentity]::Impersonate(0)
[System.Security.Principal.WindowsIdentity]::GetCurrent().name


#net user /add Fire Testing123
#$startInfo = New-Object StartupInfo
#$processinfo = New-Object ProcessInformation
#[Pinvoke.advapi32]::CreateProcessWithLogonW('Fire','.','Testing123',[LogonFlags]::DEFAULT, 'cmd.exe','c:\windows\system32\cmd.exe',[CreationFlags]::CREATE_NEW_CONSOLE, 0, 'c:\', [ref]$startInfo,[ref]$processinfo)



#working with GMSA and psexec
#Getting to system will allow you to copy the token from another users process.
.\PsExec.exe -u jps\msa-records$ -p ~ -i -d -accepteula cmd
$cmd = Get-process cmd
[intptr]$ProcessToken = 0
[intptr] $ImpersonationToken = 0 
[Pinvoke.advapi32]::OpenProcessToken($cmd.handle, [security.principal.tokenaccesslevels]::Duplicate,[ref]$ProcessToken)
[Pinvoke.advapi32]::DuplicateTokenEx($ProcessToken, [System.Security.Principal.TokenAccessLevels]::MaximumAllowed, [ref] $SecurityAttibutes, [SECURITY_IMPERSONATION_LEVEL]::SecurityImpersonation, [TOKEN_TYPE]::TokenImpersonation, [ref] $ImpersonationToken)


[System.Security.Principal.WindowsIdentity]::Impersonate($ImpersonationToken)
[System.Security.Principal.WindowsIdentity]::GetCurrent().name





#gmsa password
#you have to be running as an account in the group you specified to retrieve passwords
$gmsa = 'MSA-records'
$Pass = get-adserviceaccount -Identity $gmsa -Properties 'msDS-ManagedPassword'
$blob = [byte[]]$Pass.'msDS-ManagedPassword'
$MemoryStream = [System.IO.MemoryStream]($Pass.'msDS-ManagedPassword')

$reader = [System.IO.BinaryReader]::new($MemoryStream) #PSv5
$version = $reader.ReadInt16()
$reserved = $reader.readint16()
$Length - $reader.ReadInt32()
$currentpasswordOffset = $reader.ReadInt16()
$MaxLength = $blob.Length - $currentpasswordOffset

$stringBuilder = New-Object text.stringbuilder $MaxLength
for ($Location = $currentpasswordOffset; $Location -le $blob.Length; $Location += [text.unicodeEncoding]::CharSize){
    $character = [System.BitConverter]::ToChar($blob,$Location)
    If ($character -eq [char]::MinValue){
        break
    }
   $Null =  $stringBuilder.Append($character)
}

$previousPassOffSet = $reader.ReadInt16()
$QueryPasswordOffset = $reader.ReadInt16()
[timespan]::FromTicks([System.BitConverter]::ToInt64($blob,$QueryPasswordOffset))
Write-output -InputObject   $stringBuilder.ToString()


#build object
$GMSASecureString = ConvertTo-SecureString -String $stringBuilder.ToString() -AsPlainText -Force
$GMSACred = New-object pscredential @("JPS\$gmsa$",$GMSASecureString)

#test creds
add-type -AssemblyName system.directoryservices.accountmanagement
$domain = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
$PC = [System.DirectoryServices.AccountManagement.PrincipalContext]::new([System.DirectoryServices.AccountManagement.ContextType]::Domain,$domain)
$pc.ValidateCredentials($GMSACred.GetNetworkCredential().username,$GMSACred.GetNetworkCredential().Password)


$startInfo = New-Object StartupInfo
$processinfo = New-Object ProcessInformation
[Pinvoke.advapi32]::CreateProcessWithLogonW($GMSACred.GetNetworkCredential().username,$GMSACred.GetNetworkCredential().domain,$GMSACred.GetNetworkCredential().Password,[LogonFlags]::LOGON_NETCREDENTIALS_ONLY, 'cmd.exe','c:\windows\system32\cmd.exe',[CreationFlags]::CREATE_DEFAULT_ERROR_MODE, 0, 'c:\', [ref]$startInfo,[ref]$ProcessInfo)
