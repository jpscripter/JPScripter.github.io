function Invoke-SqlQuery
    {
    [cmdletbinding()]
    Param (
        [string]
        $Query, 
        
        [System.Collections.Hashtable]
        $Parameters,
        
        [string]
        $ConnectionString,
        
        [System.Data.SqlClient.SqlConnection]
        $SQLConnection,
        
        [int]
        $TimeOut = 60,
        
        [System.Data.CommandType]
        $CommandType = 'Text' )

    try
        {
        If ( $SQLConnection )
            {
            $SQLConnection = $SQLConnection.Clone()
            }
        Else
            {
            $SQLConnection = New-Object System.Data.SQLClient.SQLConnection $ConnectionString
            }

        #  Create the SQL command object as specified
        $SQLCommand = $SQLConnection.CreateCommand()

        $SQLCommand.CommandText    = $Query
        $SQLCommand.CommandType    = $CommandType
		$SQLCommand.CommandTimeout = $TimeOut
        If ( $Parameters )
            {
            ForEach ( $Key in $Parameters.Keys )
                {
                [void]$SQLCommand.Parameters.AddWithValue( $Key, $Parameters[$Key] )
                }
            }

        #  Execute the Command
        $SQLConnection.Open()

        $SQLReader = $SQLCommand.ExecuteReader()

        $Datatable = New-Object System.Data.DataTable
        While ( $SQLReader.VisibleFieldCount )
            {
            try { $DataTable.Load( $SQLReader ) } catch {}
            }

        return $DataTable | Select $DataTable.Columns.ColumnName
        }
    finally
        {
        If ( $SQLConnection -and $SQLConnection.State -ne [System.Data.ConnectionState]::Closed )
            {
            $SQLConnection.Close()
            }
        }
    }